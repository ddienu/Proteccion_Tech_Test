package com.diegonunez.TechTestProteccion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechTestProteccionApplicationTests {

	@Test
	void contextLoads() {
	}

}
