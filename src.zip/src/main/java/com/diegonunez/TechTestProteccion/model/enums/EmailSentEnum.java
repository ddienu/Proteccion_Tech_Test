package com.diegonunez.TechTestProteccion.model.enums;

public enum EmailSentEnum {
    SEND,
    PENDING,
    ERROR

}
