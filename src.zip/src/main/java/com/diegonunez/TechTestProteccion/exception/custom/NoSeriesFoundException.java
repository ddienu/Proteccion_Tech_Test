package com.diegonunez.TechTestProteccion.exception.custom;

public class NoSeriesFoundException extends RuntimeException{

    public NoSeriesFoundException(String message){
        super(message);
    }
}
