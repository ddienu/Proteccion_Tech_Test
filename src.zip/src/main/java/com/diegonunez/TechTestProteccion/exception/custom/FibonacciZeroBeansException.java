package com.diegonunez.TechTestProteccion.exception.custom;

public class FibonacciZeroBeansException extends RuntimeException{

    public FibonacciZeroBeansException(String message){
        super(message);
    }
}
