package com.diegonunez.TechTestProteccion.exception.custom;

public class SeriesLengthException extends RuntimeException{

    public SeriesLengthException(String message){
        super(message);
    }
}
