package com.diegonunez.TechTestProteccion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechTestProteccionApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechTestProteccionApplication.class, args);
	}

}
